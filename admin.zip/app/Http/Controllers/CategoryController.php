<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use App\Models\Category;

class CategoryController extends Controller
{
    public function category_api()
    {
        $response = category::all(); // Or any other query you need
        return response()->json(['categories' => $response]);
    }


    public function create()
    {
        return Inertia::render('category/AddCategory');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'shop_type' => 'required|string',
            
            
        ]);
    
       
        Category::create([
            'title' => $request->title,
            'shop_type' => $request->shop_type,
            
        ]);
    
        return redirect()->route('category.add')->with('success', 'Category created successfully.');
    }

    public function edit($id)
{
    $category = Category::findOrFail($id);
    return Inertia::render('category/EditCategory', ['category' => $category]);
}


    public function destroy($id)
    {
        $item = Category::findOrFail($id);
        $item->delete();

        return response()->json(['message' => 'Item deleted successfully!'], 200);
    }

}
