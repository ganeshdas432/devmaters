<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use App\Models\Appuser;
use App\Models\Product;


class AppUserController extends Controller
{

    public function user_by_usertype($usertype)
    {
        $response = Appuser::where('user_type',$usertype)->get(); // Or any other query you need
        return response()->json(['users' => $response]);
    }


    public function store(Request $request)
    {

 
        $request->validate([
            'name' => 'required|string|max:255',
            'mobile' => 'required|string',
            'address' => 'required|string',
            'gender' => 'required|string',
            'dob' => 'nullable|string',
            'user_id' => 'nullable|string',
            'user_type' => 'required|string',
            'user_status' => 'required|string', // max 1MB
            
        ]);
    
       
    
        $user=Appuser::create([
            'name' => $request->name,
            'mobile' => $request->mobile,
            'address' => $request->address,
            'gender' => $request->gender,
            'dob' => $request->dob,
            'user_id' => $request->user_id,
            'user_type' => $request->user_type,
            'user_status' => $request->user_status,
        ]);
    
        return response()->json([
            'success' => true,
            'message' => 'User created successfully',
            'data' => $user
        ], 201);
    }

    public function edit($id)
    {
        $response = Appuser::findOrFail($id);
        return Inertia::render('appuser/Edit', ['user' => $response]);
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'user_status' => 'required|string|max:255',
        ]);
    
        // Handle image upload and shop update logic
        $response = Appuser::findOrFail($id);
    
        $response->update([
            'user_status' =>  $request->user_status,
            
        ]);
    
        return back()->with('success', ' updated successfully.');
    }


    public function getCounts()
    {
        // Get total counts by user_type
        $customerCount = Appuser::where('user_type', 'customer')->count();
        $vendorCount = Appuser::where('user_type', 'vendor')->count();
        $riderCount = Appuser::where('user_type', 'rider')->count();
        $productCount=Product::count();

        // Return the counts as a JSON response
        return response()->json([
            'customer_count' => $customerCount,
            'vendor_count' => $vendorCount,
            'rider_count' => $riderCount,
            'product_count'=>$productCount,
        ]);
    }
}
