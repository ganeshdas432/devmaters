<?php

namespace App\Http\Controllers;
use Inertia\Inertia;
use Inertia\Response;
use Illuminate\Http\Request;
use App\Models\Order;
class OrderController extends Controller
{
    function list(){
        return Inertia::render('order/OrderList');
           
        }

        public function order_api()
        {
            $response =Order::with('customer')->get();
            return response()->json(['orders' => $response]);
        }
}
