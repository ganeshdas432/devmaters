<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use App\Models\Slider;
use App\Models\Details;

class SettingController extends Controller
{
        function list(){


        return Inertia::render('settings/sliders');
        
        }

        function company_details(){

            return Inertia::render('settings/company_details');
        }

        public function sliderallapi()
        {
            $response = Slider::all(); // Or any other query you need
            return response()->json(['sliders' => $response]);
        }


        function sliderstore(Request $request){
            $request->validate([
                'shop_type' => 'required|string',
                'image' => 'nullable|image|max:1024', // max 1MB
                
            ]);

            $imagePath = null;
            if ($request->hasFile('image')) {
                $imagePath = $request->file('image')->store('sliders', 'public');
            }

            Slider::create([
                'url' => $imagePath,
                'shop_type' => $request->shop_type,
            ]);

            return redirect()->route('sliders')->with('success', 'Image Added successfully.');
        }


        public function slidedelete($id)
        {
            $item = Slider::findOrFail($id);
            $item->delete();

            return response()->json(['message' => 'Item deleted successfully!'], 200);
        }

        public function show()
        {
            // Fetch the existing company details
            $response= Details::first(); // Adjust based on your requirements
            return response()->json($response);
        }
    
        public function update(Request $request)
        {
            $request->validate([
                'title' => 'required|string|max:255',
                'mobile' => 'required|string|max:15',
                'email' => 'required|email|max:255',
                'address' => 'required|string|max:255',
                // Handle file validation if necessary
            ]);
    
            $company = Details::first(); // Fetch the existing company
    
            $company->company_name = $request->title;
            $company->company_mobile = $request->mobile;
            $company->company_email = $request->email;
            $company->company_address = $request->address;
    
            // Handle file uploads if necessary
           
            if ($request->hasFile('company_logo_square')) {
                $imagePath = $request->file('company_logo_square')->store('details', 'public');
                $company->company_logo_square=$imagePath;
            } else {
                $imagePath = $company->company_logo_square;
                $company->company_logo_square=$imagePath;
            }
        
    
            if ($request->hasFile('company_logo_rectangular')) {
                $imagePath = $request->file('company_logo_rectangular')->store('details', 'public');
                $company->company_logo_rectangular=$imagePath;
            } else {
                $imagePath = $company->company_logo_rectangular;
                $company->company_logo_rectangular=$imagePath;
            }
        
    
            $company->save();
    
            return response()->json(['message' => 'Details updated successfully']);
        }
}