<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;
    protected $fillable=['cid','total_price','address_id','payment_type','payment_id','payment_status','order_status','delivered_by'];
    
     public function orderDetails()
    {
        return $this->hasMany(Orderdetail::class);
    }

    public function customer()
    {
        return $this->belongsTo(Appuser::class, 'cid', 'id');
    }
}
