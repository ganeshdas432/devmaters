<template>
    <div class="flex min-h-screen bg-gray-100">
      <!-- Sidebar -->
      <Drawer v-model:visible="showingSidebar" header="Menu">
        <Sidebar/>
      </Drawer>
  
      <!-- Main Content -->
      <div class="flex-1 lg:ml-100">
        <!-- Navbar -->
        <nav class="bg-white border-b border-gray-100">
          <div class="max-w-full mx-auto m-2">
            <div class="flex justify-between h-16">
              <div class="flex">
                <!-- Hamburger Button for Small Screens -->
                <button @click="showingSidebar = !showingSidebar" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 focus:text-gray-500 transition duration-150 ease-in-out lg:hidden">
                  <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                    <path :class="{ hidden: showingSidebar, 'inline-flex': !showingSidebar }" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                    <path :class="{ hidden: !showingSidebar, 'inline-flex': showingSidebar }" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
  
                <!-- Logo -->
                <div class="shrink-0 flex items-center sm:ms-10">
                  <Link :href="route('dashboard')" class="flex items-center text-lg font-semibold text-gray-800">
              <img v-if="company.company_logo_square" :src="'storage/' + company.company_logo_square" alt="Company Logo" class="w-10 h-10 rounded-full mr-2" />
              <span>{{ company.company_name || 'Loading...' }}</span>
            </Link>
                </div>
  
                <!-- Navigation Links -->
                <div class="hidden space-x-8 sm:-my-px sm:ms-10 sm:flex">
                  <NavLink :href="route('dashboard')" :active="route().current('dashboard')">
                    Dashboard
                  </NavLink>
                </div>
              </div>
  
              <div class="hidden sm:flex sm:items-center sm:ms-6">
                <!-- Settings Dropdown -->
                <div class="ms-3 relative">
                  <Dropdown align="right" width="48">
                    <template #trigger>
                      <span class="inline-flex rounded-md">
                        <button type="button" class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition ease-in-out duration-150">
                          {{ $page.props.auth.user.name }}
                          <svg class="ms-2 -me-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                          </svg>
                        </button>
                      </span>
                    </template>
                    <template #content>
                      <DropdownLink :href="route('profile.edit')">Profile</DropdownLink>
                      <DropdownLink :href="route('logout')" method="post" as="button">Log Out</DropdownLink>
                    </template>
                  </Dropdown>
                </div>
              </div>
            </div>
          </div>
        </nav>
  
        <!-- Page Content -->
        <main>
  <div class="flex flex-row">
    <!-- Static Sidebar for Desktop (hidden on mobile and tablet) -->
    <div class="hidden lg:block basis-1/6">
      <Sidebar class="m-4" />
    </div>

    <!-- Main Content Area -->
    <div class="flex-1"><slot /></div>
  </div>
</main>

      </div>
    </div>
  </template>
  
  <script setup>
import { ref, onMounted } from 'vue';
import Sidebar from './Sidebar.vue';
  import ApplicationLogo from '@/Components/ApplicationLogo.vue';
  import Dropdown from '@/Components/Dropdown.vue';
  import NavLink from '@/Components/NavLink.vue';
  import { Link } from '@inertiajs/vue3';
  
import Drawer from 'primevue/drawer';

  const showingSidebar = ref(false);
  const company = ref({});

  const fetchCompanyDetails = async () => {
    try {
        const response = await axios.get('/api/details');
        company.value = response.data;

        console.log('Company Details:', response.data);

    } catch (error) {
        console.error('Error fetching company details:', error);
    }
};


  onMounted(() => {
    fetchCompanyDetails();
});
  </script>
 