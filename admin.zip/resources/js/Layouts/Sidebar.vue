<template>
  <PanelMenu :model="items" class="w-150">
    <template #item="{ item }">
      <!-- Internal Links -->
      <a v-if="item.route" v-ripple class="flex items-center cursor-pointer text-surface-700 dark:text-surface-0 px-4 py-2" :href="route(item.route)" :target="item.target">
        <span :class="item.icon" />
        <span class="ml-2">{{ item.label }}</span>
        <span v-if="item.items" class="pi pi-angle-down text-primary ml-auto" />
      </a>
      
      <!-- External Links -->
      <a v-else v-ripple class="flex items-center cursor-pointer text-surface-700 dark:text-surface-0 px-4 py-2" :href="item.url" :target="item.target">
        <span :class="item.icon" />
        <span class="ml-2">{{ item.label }}</span>
        <span v-if="item.items" class="pi pi-angle-down text-primary ml-auto" />
      </a>
    </template>
  </PanelMenu>
</template>

<script setup>
import { ref } from 'vue';
import PanelMenu from 'primevue/panelmenu';

// Define menu items
const items = ref([
 
  {
    label: 'Dashboard',
    icon: 'pi pi-link',
    route: 'dashboard'
  },
  { label: 'Customers', icon: 'pi pi-eraser', route: 'customerlist' }, // Use route name 'dashboard'
  { label: 'Vendors', icon: 'pi pi-eraser', route: 'vendorlist' }, // Use route name 'dashboard'
  { label: 'Riders', icon: 'pi pi-eraser', route: 'riderlist' }, // Use route name 'dashboard'

  { label: 'Shops', icon: 'pi pi-eraser', route: 'shoplist' }, // Use route name 'dashboard'

  { label: 'Product', icon: 'pi pi-eraser', route: 'productlist' },
  
  { label: 'Orders', icon: 'pi pi-eraser', route: 'orders' }, // Use route name 'dashboard'
  { label: 'Deliveries', icon: 'pi pi-eraser', route: 'dashboard' }, // Use route name 'dashboard'
  { label: 'Ratings', icon: 'pi pi-star',  route: 'ratings' },

  { label: 'Setting', icon: 'pi pi-wrench', route: 'company_details' }
]);
</script>
