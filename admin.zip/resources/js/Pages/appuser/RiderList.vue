<template>
   
    <Head title="Dashboard" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">Dashboard</h2>
        </template>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="card">
                    <DataTable :value="customers" paginator :rows="5" :rowsPerPageOptions="[5, 10, 20, 50]" tableStyle="min-width: 50rem">
                        <Column field="id" header="ID" style="width: 25%"></Column>

                        <Column field="name" header="Name" style="width: 25%"></Column>
                        <Column field="mobile" header="Mobile" style="width: 25%"></Column>
                        <Column field="address" header="Address" style="width: 25%"></Column>
                        <Column field="user_status" header="Status" style="width: 25%"></Column>
                        <Column header="Actions" style="width: 4rem">
                            <template #body="slotProps">
                                <Button type="button" icon="pi pi-pencil" text size="small" @click="handleEdit(slotProps.data)" />

                            </template>
                        </Column>
                    </DataTable>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
   
</template>

<script setup>
import { ref ,onMounted} from 'vue';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head } from '@inertiajs/vue3';
import { Inertia } from '@inertiajs/inertia';

import DataTable from 'primevue/datatable';
import Column from 'primevue/column';
import Button from 'primevue/button';

import axios from 'axios';



const customers = ref([]); // Reactive array to hold the categories

onMounted(async () => {
    try {
        const response = await axios.get('/api/appuser/rider');
        customers.value = response.data.users; // Set the fetched categories
    } catch (error) {
        console.error('Error fetching customers data:', error);
    }
});
function handleEdit(rowData) {
    Inertia.visit(`/appuser/edit/${rowData.id}`);
  }
</script>
