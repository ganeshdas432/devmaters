<template>
      <Toast />

  <Head title="Edit Shop" />

  <AuthenticatedLayout>
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">Edit Shop</h2>
    </template>

    <div class="py-12">
      <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="card flex justify-center p-4">
          <form @submit.prevent="submitForm" class="w-full max-w-lg">
            <!-- First Row: Shop Name and File Upload -->
            <div class="grid grid-cols-2 gap-4 mb-4">
  
  <!-- Shop Type Dropdown -->
  <div>
    <label for="user_status" class="block text-sm font-medium mb-1">User Status</label>
    <Select
      id="user_status"
      v-model="Form.user_status"
      :options="userStatus"
      optionLabel="name"
      optionValue="code" 
      placeholder="Select Shop Type"
      class="w-full p-1 border rounded"
    />
  </div>

  <!-- Centered Button -->
  <div class="flex justify-center items-center mt-5">
    <Button type="submit" class="btn btn-primary">Update</Button>
  </div>

</div>

          
            <!-- Submit Button -->
           
          </form>
        </div>
      </div>
    </div>
  </AuthenticatedLayout>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useForm } from '@inertiajs/vue3';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head } from '@inertiajs/vue3';
import InputText from 'primevue/inputtext';
import Button from 'primevue/button';
import Select from 'primevue/select';
import FileUpload from 'primevue/fileupload';

import { useToast } from "primevue/usetoast";
 

const toast = useToast();



// Define props to receive 'shop' from the backend
const props = defineProps(['user']);

// Available shop types for the Select dropdown
const userStatus = ref([
  { name: 'Active', code: 'active' },
  { name: 'Inactive', code: 'inactive' },
  { name: 'Pending', code: 'pending' }

]);

// Initialize the form with default values
const Form = useForm({
  user_status: props.user?.user_status || '',
});

const errors = ref({});  // Initialize an empty errors object



// Handle form submission
const submitForm = () => {

  const formData = new FormData();
  formData.append('user_status', Form.user_status);



  Form.post(route('appuser.update', { id: props.user.id }), {
    data: formData,  
    onSuccess: () => {
      console.log("updated");
      toast.add({ severity: 'success', summary: 'Updated', detail: 'Updated Successfully', life: 3000 });

    },
    onError: (serverErrors) => {
      errors.value = serverErrors;  // Capture errors from the backend
      console.log(serverErrors);  // Log the errors to the console for debugging
    },
  });
};

</script>
