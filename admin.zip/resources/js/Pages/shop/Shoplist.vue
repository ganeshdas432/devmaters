<template>
    <Head title="Dashboard" />
  
    <AuthenticatedLayout>
      <template #header>
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Dashboard</h2>
      </template>
  
      <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div class="flex justify-between items-center mb-4">
            <h4 class="text-lg font-semibold mr-4">Shop List</h4>
            <a
              class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 ml-4"
              :href="route('shop.add')"
            >
              Add Shop
            </a>
          </div>
          <div class="card">
            <DataTable :value="shops" paginator :rows="5" :rowsPerPageOptions="[5, 10, 20, 50]" tableStyle="min-width: 50rem">
              <Column field="id" header="ID" style="width: 25%"></Column>
  
              <Column header="Image" style="width: 10%">
                  <template #body="slotProps">
                    <img :src="`/storage/${slotProps.data.image}`" alt="Shop Image" class="w-16 h-16 object-cover" />
                  </template>
                </Column>
                <Column field="shop_name" header="Shop Name" style="width: 25%"></Column>
                <Column field="address" header="Address" style="width: 25%"></Column>
                <Column field="mobile" header="Mobile" style="width: 25%"></Column>
                <Column field="shop_type" header="Shop Type" style="width: 25%"></Column>
                <Column field="status" header="Status" style="min-width: 200px">
                    <template #body="slotProps">
                        <Tag :value="slotProps.data.status" :severity="getSeverity(slotProps.data.status)" />
                    </template>
                </Column>
                <Column header="Actions" style="width: 4rem">
                  <template #body="slotProps">

                    <Button type="button" icon="pi pi-pencil" text size="small" @click="handleAction(slotProps.data)" />
                  </template>
                </Column>
            </DataTable>
          </div>
        </div>
      </div>
    </AuthenticatedLayout>
  </template>
  
  <script setup>
  import { ref, onMounted } from 'vue';
  import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
  import { Head } from '@inertiajs/vue3';
  import { Inertia } from '@inertiajs/inertia';
  import DataTable from 'primevue/datatable';
  import Column from 'primevue/column';
  import Button from 'primevue/button';
  import Tag from 'primevue/tag';
  import axios from 'axios';
  
  const shops = ref([]);
  
  onMounted(async () => {
    try {
      const response = await axios.get('/api/shoplist');
      shops.value = response.data.shops;
    } catch (error) {
      console.error('Error fetching shop data:', error);
    }
  });
  
  function handleAction(rowData) {
    Inertia.visit(`/shops/edit/${rowData.id}`);
  }
  function handleUserAsign(rowData) {
    Inertia.visit(`/shops/asignuser/${rowData.id}`);
  }
  const getSeverity = (status) => {
    switch (status) {
        case 'inactive':
            return 'danger';

        case 'active':
            return 'success';
  
    }
};
  async function updateStatus(shop) {
  try {
    // Toggle status between 'active' and 'inactive'
    const newStatus = shops.status ? 'inactive' : 'active';
    
    await axios.put(`/api/shops/${shop.id}/status`, { status: newStatus });
    
    // Update local data
    shops.status = newStatus;

  console.log(newStatus);
  } catch (error) {
    console.error('Error updating status:', error);
  }
}
  </script>


  