<template>
    <Head title="Dashboard" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">Dashboard</h2>
        </template>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="flex justify-between items-center mb-4">
                    <h4 class="text-lg font-semibold mr-4">Product List</h4>
                    <div>
                        <a class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 ml-4" :href="route('add_product')">
                            Add Product
                        </a>
                        <a class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 ml-4" :href="route('categorylist')">
                            Categories
                        </a>
                        <a class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 ml-4" :href="route('unitlist')">
                            Units
                        </a>
                    </div>
                </div>

                <div v-if="loading" class="text-center">Loading...</div>
                <div v-if="error" class="text-center text-red-500">Error loading products. Please try again later.</div>

                <div v-if="!loading && !error">
                    <DataTable :value="products" :sortOrder="sortOrder" :sortField="sortField" @sort="onSortChange" :paginator="true" :rows="rowsPerPage" :first="first" @page="onPageChange">
                        <template #header>
                            <Select v-model="sortKey" :options="sortOptions" optionLabel="label" placeholder="Sort By Price" @change="onSortChange($event)" />
                        </template>
                        <Column field="id" header="ID" sortable></Column>

                        <Column header="Image">
                            <template #body="slotProps">
                                <img class="block mx-auto rounded w-full" :src="slotProps.data.image ? '/storage/' + slotProps.data.image : '/storage/products/default.png'" :alt="slotProps.data.product_name" style="max-width: 150px; object-fit: cover;" />
                            </template>
                        </Column>
                        <Column field="product_name" header="Product Name" sortable></Column>
                        <Column field="category.title" header="Category"></Column>
                        <Column field="shop.shop_name" header="Shop Name"></Column>
                        <Column field="average_rating" header="Rating">
                            <template #body="slotProps">
                                <div class="bg-surface-100 p-1" style="border-radius: 30px">
                                    <div class="bg-surface-0 flex items-center gap-2 justify-center py-1 px-2" style="border-radius: 30px; box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.04), 0px 1px 2px 0px rgba(0, 0, 0, 0.06)">
                                        <span class="text-surface-900 font-medium text-sm">{{ slotProps.data.average_rating ? slotProps.data.average_rating.toFixed(1) : 'No Ratings' }}</span>
                                        <i class="pi pi-star-fill text-yellow-500"></i>
                                    </div>
                                </div>
                            </template>
                        </Column>
                        <Column header="Actions">
                            <template #body="slotProps">
                                <div class="flex gap-2">
                                    <Button icon="pi pi-eye" outlined></Button>
                                    <Button icon="pi pi-pencil" outlined @click="goToEditPage(slotProps.data.id)"></Button>
                                    <Button icon="pi pi-lock" outlined></Button>
                                </div>
                            </template>
                        </Column>
                    </DataTable>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>


<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head } from '@inertiajs/vue3';
import { Inertia } from '@inertiajs/inertia';

import DataTable from 'primevue/datatable';
import Column from 'primevue/column';
import Select from 'primevue/select';
import Button from 'primevue/button';

const products = ref([]);
const sortKey = ref(null);
const sortOrder = ref(null);
const sortField = ref(null);
const sortOptions = ref([
    {label: 'Price High to Low', value: '!price'},
    {label: 'Price Low to High', value: 'price'},
]);

const loading = ref(true);
const error = ref(false);
const rowsPerPage = ref(5); // Number of rows per page
const first = ref(0); // Index of the first row on the current page

const fetchProducts = async () => {
    try {
        const response = await axios.get('/api/products');
        products.value = response.data;
    } catch (e) {
        error.value = true;
        console.error('Failed to fetch products:', e);
    } finally {
        loading.value = false;
    }
};

const onSortChange = (event) => {
    const value = event.sortField;
    if (event.sortOrder === -1) {
        sortOrder.value = -1;
        sortField.value = value;
        sortKey.value = value;
    } else {
        sortOrder.value = 1;
        sortField.value = value;
        sortKey.value = value;
    }
};

const onPageChange = (event) => {
    first.value = event.first;
    rowsPerPage.value = event.rows;
    // You might want to refetch products based on new pagination settings
    // For now, this just updates pagination state
};

onMounted(() => {
    fetchProducts();
});

const goToEditPage = (productId) => {
    Inertia.visit(`/products/${productId}/edit`);
};
</script>
