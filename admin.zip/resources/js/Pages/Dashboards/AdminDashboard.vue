<template>
    <div class="container mx-auto p-4">
        <!-- Cards Section -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card v-for="card in cards" :key="card.id">
                <template #title>{{ card.title }}</template>
                <template #content>
                    <p class="m-0">{{ card.content }}</p>
                </template>
            </Card>
        </div>

        <!-- Charts Section -->
      
    </div>
</template>

<script>
import Card from "primevue/card";
import Chart from "primevue/chart";
import axios from 'axios';  // Import axios for API calls

export default {
    components: {
        Card,
        Chart
    },
    data() {
        return {
            // Placeholder values initially
            cards: [
                { id: 1, title: 'Products', content: '' },
                { id: 2, title: 'Orders', content: '' },   // Set empty content initially
                { id: 3, title: 'Customers', content: '' }, // Set empty content initially
                { id: 4, title: 'Vendors', content: '' },   // Set empty content initially
                { id: 4, title: 'Riders', content: '' }, 
            ],
            doughnutChartData: {
                labels: ['A', 'B', 'C'],
                datasets: [
                    {
                        data: [540, 325, 702],
                        backgroundColor: ['#00B0FF', '#FFAB00', '#B0BEC5'],
                        hoverBackgroundColor: ['#00A3E0', '#FF9100', '#90A4AE']
                    }
                ]
            },
            doughnutChartOptions: {
                plugins: {
                    legend: {
                        labels: {
                            color: '#000000'
                        }
                    }
                }
            },
            barChartData: {
                labels: ['Q1', 'Q2', 'Q3', 'Q4'],
                datasets: [
                    {
                        label: 'Sales',
                        data: [540, 325, 702, 620],
                        backgroundColor: [
                            'rgba(249, 115, 22, 0.2)',
                            'rgba(6, 182, 212, 0.2)',
                            'rgba(107, 114, 128, 0.2)',
                            'rgba(139, 92, 246, 0.2)'
                        ],
                        borderColor: [
                            'rgb(249, 115, 22)',
                            'rgb(6, 182, 212)',
                            'rgb(107, 114, 128)',
                            'rgb(139, 92, 246)'
                        ],
                        borderWidth: 1
                    }
                ]
            },
            barChartOptions: {
                plugins: {
                    legend: {
                        labels: {
                            color: '#000000'
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: '#6B7280'
                        },
                        grid: {
                            color: '#D1D5DB'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: '#6B7280'
                        },
                        grid: {
                            color: '#D1D5DB'
                        }
                    }
                }
            }
        };
    },
    mounted() {
        // Fetch the data from the API when the component is mounted
        this.fetchCounts();
    },
    methods: {
        async fetchCounts() {
            try {
                const response = await axios.get('/api/counts');  // Assuming this is your API endpoint

                const { customer_count, vendor_count, order_count,rider_count,product_count } = response.data;

                // Update the content of the cards with the fetched counts
                this.cards = [
                    { id: 1, title: 'Products', content: product_count }, // Assuming static value
                    { id: 2, title: 'Orders', content: order_count },   // Set orders count from API
                    { id: 3, title: 'Customers', content: customer_count }, // Set customer count from API
                    { id: 4, title: 'Vendors', content: vendor_count },   // Set vendor count from API
                    { id: 4, title: 'Riders', content: rider_count },   // Set vendor count from API

                ];
            } catch (error) {
                console.error("Failed to fetch data:", error);
            }
        }
    }
};
</script>

<style scoped>
.card {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100%;
}

.card .relative {
    position: relative;
    width: 100%;
    height: 100%;
}

.card .absolute {
    position: absolute;
    inset: 0;
}
</style>
