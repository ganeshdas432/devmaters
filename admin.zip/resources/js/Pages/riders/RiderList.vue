<template>

    <Head title="Dashboard" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">Categories</h2>
        </template>



        <div class="py-12">

            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="flex justify-between items-center mb-4">
                    <h4 class="text-lg font-semibold mr-4">Rider List</h4>
                    <Button class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 ml-4">
                        Add Rider
                    </Button>
                </div>
                <div class="card">
                    <DataTable :value="customers" paginator :rows="5" :rowsPerPageOptions="[5, 10, 20, 50]"
                        tableStyle="min-width: 50rem">
                        <Column field="id" header="ID" style="width: 25%"></Column>

                        <Column field="name" header="Name" style="width: 25%"></Column>
                        <Column field="country.name" header="Country" style="width: 25%"></Column>
                        <Column field="company" header="Company" style="width: 25%"></Column>
                        <Column field="representative.name" header="Representative" style="width: 25%"></Column>
                        <Column header="Actions" style="width: 4rem">
                            <template #body="slotProps">
                                <div class="flex justify-between items-center mb-4">
                                    <Button type="button" icon="pi pi-pencil" text size="small"
                                    @click="handleAction(slotProps.data)" />
                                    <Button type="button" icon="pi pi-trash" text size="small"
                                    @click="handleAction(slotProps.data)" />
                                </div>
                               
                            </template>
                        </Column>
                    </DataTable>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { ref } from 'vue';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head } from '@inertiajs/vue3';
import DataTable from 'primevue/datatable';
import Column from 'primevue/column';
import Button from 'primevue/button';

// Static customer data
const customers = ref([
    {
        name: 'John Doe',
        country: { name: 'United States' },
        company: 'Example Corp',
        representative: { name: 'Amy Elsner' },
    },
    {
        name: 'Jane Smith',
        country: { name: 'Germany' },
        company: 'ABC Inc',
        representative: { name: 'Anna Fali' },
    },
    {
        name: 'Michael Brown',
        country: { name: 'Canada' },
        company: 'Tech Solutions',
        representative: { name: 'Stephen Shaw' },
    },
    {
        name: 'Emily Davis',
        country: { name: 'United Kingdom' },
        company: 'Web World',
        representative: { name: 'Troy Magno' },
    },
    {
        name: 'Chris Wilson',
        country: { name: 'Australia' },
        company: 'Digital Agency',
        representative: { name: 'Alfredo Kraus' },
    },
    {
        name: 'Sara Johnson',
        country: { name: 'France' },
        company: 'Creative Minds',
        representative: { name: 'Elwin Sharvill' },
    },
    {
        name: 'David Lee',
        country: { name: 'Japan' },
        company: 'Global Tech',
        representative: { name: 'Ioni Bowcher' },
    },
]);

// Action handler for button click
function handleAction(rowData) {
    console.log('Action button clicked for:', rowData);
    // You can add your action logic here
}
</script>
