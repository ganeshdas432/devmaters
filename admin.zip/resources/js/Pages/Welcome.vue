<script setup>
import { ref } from "vue";

import { Head, Link } from '@inertiajs/vue3';
import Menubar from 'primevue/menubar';
import Carousel from "primevue/carousel";
import Card from "primevue/card";
import Image from "primevue/image";
import Splitter from 'primevue/splitter';
import SplitterPanel from 'primevue/splitterpanel';


defineProps({
    canLogin: {
        type: Boolean,
    },
    canRegister: {
        type: Boolean,
    },
    laravelVersion: {
        type: String,
        required: true,
    },
    phpVersion: {
        type: String,
        required: true,
    },
});

const items = ref([
    {
        label: 'Home',
        route: 'home'
    },
    {
        label: 'About Us',
        route: 'about'
    },
    {
        label: 'Terms and Conditions',
        route: 'terms'
    },
    {
        label: 'Privacy Policies',
        route: 'privacy'
    },
    {
        label: 'Contact',
        route: 'contact'
    },

]);

const products = ref([
    {
        id: 1,
        name: 'Black Watch',
        price: 79.99,
        image: 'https://www.slideteam.net/wp/wp-content/uploads/2022/09/Banner_design_268b.png',
        inventoryStatus: 'INSTOCK',
    },
    {
        id: 2,
        name: 'Blue Band',
        price: 39.99,
        image: 'https://www.railkafe.com/assets/top-banner-image-new-DIf96RMj.webp',
        inventoryStatus: 'LOWSTOCK',
    },

]);

const responsiveOptions = ref([
    {
        breakpoint: '1400px',
        numVisible: 1,
        numScroll: 1
    },
    {
        breakpoint: '1199px',
        numVisible: 1,
        numScroll: 1
    },
    {
        breakpoint: '767px',
        numVisible: 1,
        numScroll: 1
    },
    {
        breakpoint: '575px',
        numVisible: 1,
        numScroll: 1
    }
]);

const getSeverity = (status) => {
    switch (status) {
        case 'INSTOCK':
            return 'success';
        case 'LOWSTOCK':
            return 'warn';
        case 'OUTOFSTOCK':
            return 'danger';
        default:
            return null;
    }
};
</script>

<template>

    <Head title="Welcome" />


    <div class="card">
        <Menubar :model="items">
            <template #start>
                <svg width="35" height="40" viewBox="0 0 35 40" fill="none" xmlns="http://www.w3.org/2000/svg"
                    class="h-8">
                    <path
                        d="M25.87 18.05L23.16 17.45L25.27 20.46V29.78L32.49 23.76V13.53L29.18 14.73L25.87 18.04V18.05ZM25.27 35.49L29.18 31.58V27.67L25.27 30.98V35.49ZM20.16 17.14H20.03H20.17H20.16ZM30.1 5.19L34.89 4.81L33.08 12.33L24.1 15.67L30.08 5.2L30.1 5.19ZM5.72 14.74L2.41 13.54V23.77L9.63 29.79V20.47L11.74 17.46L9.03 18.06L5.72 14.75V14.74ZM9.63 30.98L5.72 27.67V31.58L9.63 35.49V30.98ZM4.8 5.2L10.78 15.67L1.81 12.33L0 4.81L4.79 5.19L4.8 5.2ZM24.37 21.05V34.59L22.56 37.29L20.46 39.4H14.44L12.34 37.29L10.53 34.59V21.05L12.42 18.23L17.45 26.8L22.48 18.23L24.37 21.05ZM22.85 0L22.57 0.69L17.45 13.08L12.33 0.69L12.05 0H22.85Z"
                        fill="var(--p-primary-color)" />
                    <path
                        d="M30.69 4.21L24.37 4.81L22.57 0.69L22.86 0H26.48L30.69 4.21ZM23.75 5.67L22.66 3.08L18.05 14.24V17.14H19.7H20.03H20.16H20.2L24.1 15.7L30.11 5.19L23.75 5.67ZM4.21002 4.21L10.53 4.81L12.33 0.69L12.05 0H8.43002L4.22002 4.21H4.21002ZM21.9 17.4L20.6 18.2H14.3L13 17.4L12.4 18.2L12.42 18.23L17.45 26.8L22.48 18.23L22.5 18.2L21.9 17.4ZM4.79002 5.19L10.8 15.7L14.7 17.14H14.74H15.2H16.85V14.24L12.24 3.09L11.15 5.68L4.79002 5.2V5.19Z"
                        fill="var(--p-text-color)" />
                </svg>
            </template>
            <template #item="{ item }">
                <!-- Internal Links -->
                <a v-if="item.route" v-ripple
                    class="flex items-center cursor-pointer text-surface-700 dark:text-surface-0 px-4 py-2"
                    :href="route(item.route)" :target="item.target">
                    <span class="ml-2">{{ item.label }}</span>
                    <span v-if="item.items" class="pi pi-angle-down text-primary ml-auto" />
                </a>

                <!-- External Links -->
                <a v-else v-ripple
                    class="flex items-center cursor-pointer text-surface-700 dark:text-surface-0 px-4 py-2"
                    :href="item.url" :target="item.target">
                    <span class="ml-2">{{ item.label }}</span>
                    <span v-if="item.items" class="pi pi-angle-down text-primary ml-auto" />
                </a>
            </template>
            <template #end>
                <div v-if="canLogin" class="sm:top-0 sm:right-0 p-6 text-end">
                    <Link v-if="$page.props.auth.user" :href="route('dashboard')"
                        class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">
                    Dashboard</Link>

                    <template v-else>
                        <Link :href="route('login')"
                            class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">
                        Log in</Link>

                        <Link v-if="canRegister" :href="route('register')"
                            class="ms-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">
                        Register</Link>
                    </template>
                </div>
            </template>
        </Menubar>
    </div>


    <Carousel :value="products" :numVisible="1" :numScroll="1" :responsiveOptions="responsiveOptions" circular
        :autoplayInterval="3000">
        <template #item="slotProps">
            <div class=" ">
                <div class="mb-4 mt-4">
                    <div class="relative mx-auto">
                        <img :src="slotProps.data.image" :alt="slotProps.data.name" class="w-full rounded"
                            style="height: 480px; object-fit: fill;" />
                        <Tag :value="slotProps.data.inventoryStatus"
                            :severity="getSeverity(slotProps.data.inventoryStatus)" class="absolute"
                            style="left:5px; top:5px" />
                    </div>
                </div>

            </div>
        </template>
    </Carousel>




    <div class="card-grid m-4">
        <Card style="width: 100%; overflow: hidden" class="bg-red">
            <template #header>
                <img alt="user header" src="/storage/assets/images/fd.png" style="height: 150px;object-fit: cover;" />
            </template>
            <template #title>Food Delivery</template>
            <template #content>
                <p class="m-0">
                    "Craving something delicious? Let us bring it to your door!
Fresh flavors, fast delivery – a treat for every taste.
Order now and enjoy a meal without the hassle.
Your favorite food is just a tap away!"
                </p>
            </template>
            <template #footer>
                <div class="flex gap-4 mt-1">
                    <Button label="Cancel" severity="secondary" outlined class="w-full" />
                    <Button label="Save" class="w-full" />
                </div>
            </template>
        </Card>

        <Card style="width: 100%; overflow: hidden" class="bg-blue">
            <template #header>
                <img alt="user header" src="/storage/assets/images/gr.png" style="height: 150px;object-fit: cover;" />
            </template>
            <template #title>Grocery Delivery</template>
            <template #content>
                <p class="m-0">
                    "Fresh groceries, delivered straight to your door!
From pantry staples to farm-fresh produce, we’ve got it all.
Shop online and skip the checkout lines.
Convenient, fast, and always reliable – your groceries are just a click away!"
                </p>
            </template>
            <template #footer>
                <div class="flex gap-4 mt-1">
                    <Button label="Cancel" severity="secondary" outlined class="w-full" />
                    <Button label="Save" class="w-full" />
                </div>
            </template>
        </Card>

        <Card style="width: 100%; overflow: hidden" class="bg-green">
            <template #header>
                <img alt="user header" src="/storage/assets/images/pt.png" style="height: 150px;object-fit: cover;" />
            </template>
            <template #title>Porter Service</template>
            <template #content>
                <p class="m-0">
                    "Need a helping hand? Our porter service is here for you!
From luggage to heavy loads, we’ll handle it with care.
Efficient, reliable, and always on time.
Let us lighten your load – book our porter service today!"
                </p>
            </template>
            <template #footer>
                <div class="flex gap-4 mt-1">
                    <Button label="Cancel" severity="secondary" outlined class="w-full" />
                    <Button label="Save" class="w-full" />
                </div>
            </template>
        </Card>

        <Card style="width: 100%; overflow: hidden" class="bg-yellow">
            <template #header>
                <img alt="user header" src="/storage/assets/images/rd.png" style="height: 150px;object-fit: cover;" />
            </template>
            <template #title>Ride Booking</template>
            <template #content>
                <p class="m-0">
                    "Need a ride? We’ve got you covered!
Quick, safe, and hassle-free transportation at your fingertips.
Book your ride now and hit the road in minutes.
Wherever you're headed, we’ll get you there with ease!"
                </p>
            </template>
            <template #footer>
                <div class="flex gap-4 mt-1">
                    <Button label="Cancel" severity="secondary" outlined class="w-full" />
                    <Button label="Save" class="w-full" />
                </div>
            </template>
        </Card>
    </div>


    <div class="mb-36">
    </div>


    <div class="card m-4  p-0 flex-container">
        <div class="text-content p-8">
            <h2 class="text-2xl sm:text-3xl md:text-4xl text-left rtl:text-right">
                What we do ?
            </h2>
            <p>
                we are dedicated to making your life easier by offering a comprehensive range of services designed to meet all your needs. From convenient grocery delivery and reliable food services to professional porter assistance and seamless ride booking, our mission is to provide exceptional solutions that save you time and effort.
            </p>
        </div>
        <div class="image-content flex items-center justify-center">
            <picture
                class="image card-image flex sm:rounded-3xl mb-5 md:mb-0 overflow-hidden transitionFix items-center justify-center"
                style="width: 400px;"><img src="https://primefaces.org/cdn/primevue/images/galleria/galleria10.jpg"
                    alt="About_us_updt_e1e14ed645" loading="lazy"></picture>
        </div>
    </div>

    <div class="mb-36">
    </div>


    <div class="card m-4 p-0 flex-container">

        <div class="image-content flex items-center justify-center">
            <picture style="width: 400px;"
                class="image card-image flex sm:rounded-3xl mb-5 md:mb-0 overflow-hidden transitionFix items-center justify-center">
                <img src="https://careem-public-web-media.imgix.net/Engineering_at_careem_5df00df225.webp"
                    alt="Engineering_at_careem_5df00df225" loading="lazy">
            </picture>
        </div>
        <div class="text-content p-8">
            <h2 class="text-2xl sm:text-3xl md:text-4xl text-left rtl:text-right">
                Why our app better ?
            </h2>
            <div class="font-medium text-base leading-6 mb-6">
                <p>your all-in-one solution for convenience! Designed with you in mind, our app brings a world of services right to your fingertips. Whether you need groceries delivered, a quick ride, delicious food, or porter assistance, our user-friendly interface makes it easy to access everything you need in just a few taps.</p>
            </div>
           
        </div>



    </div>

    <div class="mb-36">
    </div>
   
    <div class="flex items-center justify-center  text-right">
    All Rights Resurved @2024
    
</div>




</template>

<style scoped>
.bg-dots-darker {
    background-image: url("data:image/svg+xml,%3Csvg width='30' height='30' viewBox='0 0 30 30' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1.22676 0C1.91374 0 2.45351 0.539773 2.45351 1.22676C2.45351 1.91374 1.91374 2.45351 1.22676 2.45351C0.539773 2.45351 0 1.91374 0 1.22676C0 0.539773 0.539773 0 1.22676 0Z' fill='rgba(0,0,0,0.07)'/%3E%3C/svg%3E");
}

@media (prefers-color-scheme: dark) {
    .dark\:bg-dots-lighter {
        background-image: url("data:image/svg+xml,%3Csvg width='30' height='30' viewBox='0 0 30 30' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1.22676 0C1.91374 0 2.45351 0.539773 2.45351 1.22676C2.45351 1.91374 1.91374 2.45351 1.22676 2.45351C0.539773 2.45351 0 1.91374 0 1.22676C0 0.539773 0.539773 0 1.22676 0Z' fill='rgba(255,255,255,0.07)'/%3E%3C/svg%3E");
    }
}


.card-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    /* 4 columns for larger screens */
    gap: 1rem;
    /* Add space between cards */
}

@media (max-width: 768px) {
    .card-grid {
        grid-template-columns: 1fr;
        /* Single column on smaller screens */
    }
}

.card-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    /* 4 columns for larger screens */
    gap: 1rem;
    /* Add space between cards */
}

.flex-container {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    gap: 2rem;
    /* Spacing between text and image */
}

.text-content {
    flex: 1;
}

.image-content {
    flex: 1;
}

.bg-red {
    background-color: #ff9f98;
    /* Red */
    color: rgb(24, 23, 23);
}

.bg-blue {
    background-color: #b0d8f8;
    /* Blue */
    color: rgb(30, 27, 27);
}

.bg-green {
    background-color: #b3fab6;
    /* Green */
    color: rgb(39, 36, 36);
}

.bg-yellow {
    background-color: #fff9bf;
    /* Yellow */
    color: rgb(43, 38, 38);
}

@media (max-width: 768px) {
    .card-grid {
        grid-template-columns: 1fr;
        /* Single column on smaller screens */
    }

    .flex-container {
        flex-direction: column;
        /* Stack text and image vertically on mobile */
    }

    .image-content {
        margin-top: 1rem;
        /* Add some space between text and image on mobile */
    }
}
</style>
