<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AppUserController;
use App\Http\Controllers\UnitController;
use App\Http\Controllers\ShopController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\RatingController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SettingController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/
Route::post('/add_appusers', [AppUserController::class, 'store']);

Route::get('/appuser/{usertype}', [AppUserController::class, 'user_by_usertype']);
Route::get('/counts', [AppUserController::class, 'getCounts']);
Route::get('/unitlist', [UnitController::class, 'unit_api']);
Route::get('/shoplist', [ShopController::class, 'shoplistapi']);
Route::get('/catlist', [CategoryController::class, 'category_api']);
Route::get('/products', [ProductController::class, 'index']);
Route::get('/products/{id}', [ProductController::class, 'show'])->name('api.products.show');
Route::get('/orderlist', [OrderController::class, 'order_api']);
    
// Update product details
Route::post('/products/{id}', [ProductController::class, 'update'])->name('api.products.update');


Route::get('/ratinglist', [RatingController::class, 'rating_api']);


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});



Route::get('/details', [SettingController::class, 'show']);
Route::post('/details/update', [SettingController::class, 'update']);