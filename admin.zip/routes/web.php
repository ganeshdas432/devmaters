<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ShopController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\UnitController;
use App\Http\Controllers\AppUserController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\RatingController;
use App\Http\Controllers\OrderController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
})->name('home');

Route::get('/about', function () {
    return Inertia::render('About', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
})->name('about');

Route::get('/privacy', function () {
    return Inertia::render('Privacy', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
})->name('privacy');

Route::get('/terms', function () {
    return Inertia::render('Terms', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
})->name('terms');

Route::get('/contact', function () {
    return Inertia::render('Contact', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
})->name('contact');


Route::get('/dashboard', function () {
    return Inertia::render('Dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');


Route::get('/customer_list', function () {
    return Inertia::render('appuser/CustomerList');
})->middleware(['auth', 'verified'])->name('customerlist');
Route::get('/vendor_list', function () {
    return Inertia::render('appuser/VendorList');
})->middleware(['auth', 'verified'])->name('vendorlist');
Route::get('/rider_list', function () {
    return Inertia::render('appuser/RiderList');
})->middleware(['auth', 'verified'])->name('riderlist');



Route::get('/shop_list', function () {
    return Inertia::render('shop/Shoplist');
})->middleware(['auth', 'verified'])->name('shoplist');



Route::get('/product_list', function () {
    return Inertia::render('products/ProductList');
})->middleware(['auth', 'verified'])->name('productlist');
Route::get('/category_list', function () {
    return Inertia::render('category/CategoryList');
})->middleware(['auth', 'verified'])->name('categorylist');
Route::get('/unit_list', function () {
    return Inertia::render('unit/List');
})->middleware(['auth', 'verified'])->name('unitlist');
Route::get('/order_list', function () {
    return Inertia::render('order/OrderList');
})->middleware(['auth', 'verified'])->name('orderlist');




Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::get('/shop/add', [ShopController::class, 'create'])->name('shop.add');
    Route::post('/shop', [ShopController::class, 'store'])->name('shop.store');
    Route::get('api/shop/{id}',[ShopController::class,'singleshopapi']);
    Route::get('/shops/edit/{id}', [ShopController::class, 'edit'])->name('shop.edit');
    Route::post('/shops/{id}', [ShopController::class, 'update'])->name('shop.update');
    Route::put('/api/shops/{id}/status', [ShopController::class, 'updateStatus']);

    Route::get('/category/add', [CategoryController::class, 'create'])->name('category.add');
    Route::post('/category', [CategoryController::class, 'store'])->name('category.store');
    Route::get('/category/edit/{id}', [CategoryController::class, 'edit'])->name('category.edit');
    Route::delete('api/category_delete/{id}', [CategoryController::class, 'destroy']);


    Route::get('/unit/add', [UnitController::class, 'create'])->name('unit.add');
    Route::post('/unit', [UnitController::class, 'store'])->name('unit.store');
    Route::get('/unit/edit/{id}', [UnitController::class, 'edit'])->name('unit.edit');
    Route::delete('api/unit_delete/{id}', [UnitController::class, 'destroy']);
    Route::post('/unit/{id}', [UnitController::class, 'update'])->name('unit.update');


    Route::get('company_details',[SettingController::class,'company_details'])->name('company_details');


    Route::get('sliders',[SettingController::class,'list'])->name('sliders');
    Route::post('/slider', [SettingController::class, 'sliderstore'])->name('slider.store');
    Route::get('/api/sliders',[SettingController::class,'sliderallapi']);
    Route::delete('api/slide_delete/{id}', [SettingController::class, 'slidedelete']);


    
    Route::get('/appuser/edit/{id}', [AppUserController::class, 'edit'])->name('appuser.edit');
    Route::post('/appuser/{id}', [AppUserController::class, 'update'])->name('appuser.update');


    Route::get('add_product',[ProductController::class,'add_product'])->name('add_product');
    Route::post('/product/store', [ProductController::class, 'store'])->name('product.store');
    Route::get('/products/{id}/edit', [ProductController::class, 'edit'])->name('product.edit');


    Route::get('ratings',[RatingController::class,'list'])->name('ratings');

    Route::get('orders',[OrderController::class,'list'])->name('orders');

});

require __DIR__.'/auth.php';
