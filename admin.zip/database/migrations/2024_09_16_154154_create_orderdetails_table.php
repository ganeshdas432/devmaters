<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('orderdetails', function (Blueprint $table) {
            $table->id();
            $table->integer('order_id')->unsigned();  // Order ID (integer)
            $table->integer('product_id')->unsigned();  // Product ID (integer)
            $table->string('product_name', 255);  // Product name (varchar 255)
            $table->string('product_price', 255);  // Product price (varchar 255)
            $table->string('selected_attribute', 255);  // Selected attributes (varchar 255)
            $table->integer('quantity');  // Product quantity (integer)
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orderdetails');
    }
};
