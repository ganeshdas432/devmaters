<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('details', function (Blueprint $table) {
            $table->id();
            $table->string('company_name');
            $table->string('company_mobile');
            $table->string('company_email');
            $table->string('company_address');
            $table->string('company_logo_square');
            $table->string('company_logo_rectangular');
            $table->string('company_about');
            $table->string('company_privacy');
            $table->string('company_contact');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('details');
    }
};
